﻿namespace MVCBibliotheekBENSLE.PasswordValidators
{
    public class NumberPasswordValidator
    {
    }
}
