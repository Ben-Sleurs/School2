﻿namespace MVCBibliotheekBENSLE.PasswordValidators
{
    public class LengthPasswordValidator
    {
    }
}
