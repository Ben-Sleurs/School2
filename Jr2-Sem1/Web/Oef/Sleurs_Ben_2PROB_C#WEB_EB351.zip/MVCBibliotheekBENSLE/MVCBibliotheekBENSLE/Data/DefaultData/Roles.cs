﻿namespace MVCBibliotheekBENSLE.Data.DefaultData
{
    public class Roles
    {
        public const string BibManager = "BibManager";
        public const string BibGebruiker = "BibGebruiker";
    }
}
