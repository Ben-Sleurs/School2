﻿using ClassLibTeam10.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibTeam10.Data.Framework
{
    public class InsertResult : BaseResult
    {
        public int NewId { get; set; }
    }
}