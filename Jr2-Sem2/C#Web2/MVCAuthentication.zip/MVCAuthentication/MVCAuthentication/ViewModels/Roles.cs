﻿namespace MVCAuthentication.ViewModels
{
    public static class Roles
    {
        public const string ADMIN_ROLE = "Admin";
        public const string USER_ROLE = "User";
    }
}
