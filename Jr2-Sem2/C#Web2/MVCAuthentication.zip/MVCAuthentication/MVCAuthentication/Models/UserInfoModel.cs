﻿namespace MVCAuthentication.Models
{
    public class UserInfoModel
    {
        public string UserName { get; set; }
        public string Email { get; set; }
    }
}
