using Microsoft.AspNetCore.Identity.EntityFrameworkCore;

namespace PeopleApp.Data;

public class MemoryDbContext : IdentityDbContext
{
    
}