using Microsoft.AspNetCore.Mvc.RazorPages;

namespace PeopleApp.Views.Shared;

public class _BlazorServer_Host : PageModel
{
    public void OnGet()
    {
        
    }
}