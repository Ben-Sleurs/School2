﻿namespace PeopleApp.ViewModels
{
    public class PersonEditModel
    {
        public string Firstname { get; set; }
        public string Surname { get; set; }
        public long DepartmentId { get; set; }
        public long LocationId { get; set; }
    }

}
