﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibTeam10.Settings
{
    public static class Settings
    {

        public static class Database
        {
            public static string Server = @"server=localhost\SqlExpress";
            public static string ProjectDb = @"Database=DB_2022_Team10";
            public static string IndividualDatabase = @"Database=DB_Ben_Sleurs";
            public static string Security = "Integrated security = true";
            public static string ProjectConnectionString = $"{Server};{ProjectDb};{Security}";
            public static string IndividualConnectionString = $"{Server};{IndividualDatabase};{Security}";

            private static string pxlServer = @"server=10.128.4.7";
            private static string pxlDatabase = @"database=pxl2022Team10";
            private static string pxlUser = "User Id=pxluser2022";
            private static string pxlPwd= "Password=pxluser2022";
            private static string pxlConnString= $"{  pxlServer};{pxlDatabase};{pxlUser};{pxlPwd}";
            public static string PxlConnectionString=> pxlConnString;
        }
    }
}
