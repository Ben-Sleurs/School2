﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibTeam10.Entities.GeneralEntities
{
    public class BankgegevensCheck
    {
        public WebToken WebToken { get; set; }
        public BankGegevens BankGegevens { get; set; }
    }
}
