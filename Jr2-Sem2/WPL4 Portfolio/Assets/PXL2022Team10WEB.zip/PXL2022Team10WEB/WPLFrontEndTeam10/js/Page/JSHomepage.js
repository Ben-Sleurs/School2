handleVideo();
window.addEventListener('resize',handleVideo)
window.onload = function(){
    loginCheck();
    toonAantalProducten();
}
function handleVideo(){
    let width = window.innerWidth;
    const breakpoint = 1650
    let negativemargin;
    if(width<breakpoint){
        negativemargin=width-breakpoint;
        console.log(negativemargin);
        document.getElementById("windmolensvid").style.marginLeft=`${negativemargin}px`;
    }
    else if(width>breakpoint){
        document.getElementById("windmolensvid").style.marginLeft="0";
    }
}